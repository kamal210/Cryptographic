﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace EncypDecryp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Passowrd to generate the key
        string password = "hel@k@mal";
        // Create a new instance of the EncryptDecrypt class
        EncryptDecrypt enDec = new EncryptDecrypt();

        private void Form1_Load(object sender, EventArgs e)
        {
          

        }


        private void btnEnrypted_Click(object sender, EventArgs e)
        {
            this.txtEncrypted.Text=enDec.encryption(password, this.txtPlain.Text);

        }

        private void btnDecrypted_Click(object sender, EventArgs e)
        {
            this.txtDecrypted.Text = enDec.decryption(password, this.txtEncrypted.Text);
        }
    }
}
