﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;

namespace EncypDecryp
{
    class EncryptDecrypt

    {
        //using Triple DES symentic algorithm
        static TripleDES createDES(string key)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            TripleDES tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = md5.ComputeHash(Encoding.Unicode.GetBytes(key));
            tdes.IV = new byte[tdes.BlockSize / 8];
            return tdes;

        }
        public string encryption(string password, string plainText)
        {
            // Converting Plain text into bytes
            byte[] plainTextByte = Encoding.Unicode.GetBytes(plainText);


            //using memory stream to hold the bytes
            MemoryStream memStram = new MemoryStream();

            //Create the key and initialization of the vector using the key
            TripleDES tdes = createDES(password);

            //Creating the encoder that will write to the memory stream
            CryptoStream encryptStream = new CryptoStream(memStram, tdes.CreateEncryptor(), CryptoStreamMode.Write);


            //using cryptStream to write the byte array to memory stream
            encryptStream.Write(plainTextByte,0,plainTextByte.Length);

            //Clearing the memory stream
            encryptStream.FlushFinalBlock();

            //Change the encrypted stream to printable version of string
            return Convert.ToBase64String(memStram.ToArray());


        }
        public string decryption(string password, string encryptedText)
        {
            // Converting encrypted string to byte array
            byte[] encryptedTextByte = Convert.FromBase64String(encryptedText);


            //using memory stream to hold the bytes
            MemoryStream memStream = new MemoryStream();

            //Create the key and initialization of the vector using the key
            TripleDES tdes = createDES(password);

            //Creating the decoder that will write to the memory stream
            CryptoStream decryptStream = new CryptoStream(memStream, tdes.CreateDecryptor(), CryptoStreamMode.Write);


            //using decryptStream to write the byte array to memory stream
            decryptStream.Write(encryptedTextByte, 0, encryptedTextByte.Length);

            //Clearing the memory stream
            decryptStream.FlushFinalBlock();

            //Change the decrypted stream to printable version of string
            return Encoding.Unicode.GetString(memStream.ToArray());


        }


    }
}
